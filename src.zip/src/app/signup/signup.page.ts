import { Component, OnInit } from '@angular/core';
import { FireserviceService } from '../services/fireservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  public email: string = '';
  public password: string = '';
  public name: string = '';
  public file: string = '';

  constructor(
    private router: Router,
    public fireService: FireserviceService,
  ) { }

  ngOnInit() {
  }

  signup() {
    this.fireService.signup({ email: this.email, password: this.password }).then((res: any) => {
      if (res.user?.uid) {
        let data = {
          email: this.email,
          password: this.password,
          name: this.name,
          file: this.file,
          uid: res.user.uid
        };
        this.fireService.saveDetails(data).then(() => {
          alert('Account Created!');
          this.router.navigate(['/login']);
        }).catch((err) => {
          console.log(err);
        });
      }
    }).catch((err) => {
      alert(err.message);
      console.log(err);
    });
  }
}
