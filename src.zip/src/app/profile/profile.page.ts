import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FireserviceService } from '../services/fireservice.service';
import { AuthService } from '../services/auth.service';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  currentUser: any = {};

  constructor(
    private fireService: FireserviceService,
    private router: Router,
    private authService: AuthService,
    private loadingCtrl:LoadingController
  ) {}

  public listaFilmes = new Array <any>();

  public ionViewDidEnter(){
  }

  ngOnInit() {
    this.getCurrentUser();
  }

  getCurrentUser() {
    this.fireService.getCurrentUser().then(user => {
      if (user) {
        this.currentUser = user;
      }
    }).catch(error => {
      console.error("Error fetching user details:", error);
    });
  }


}
