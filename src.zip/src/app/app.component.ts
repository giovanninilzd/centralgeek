import { Component } from '@angular/core';
import { FireserviceService } from './services/fireservice.service';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from './services/auth.service';
import { Storage } from '@ionic/storage-angular';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  showMenu = true;


  constructor(private fireService: FireserviceService,private router: Router,private authService: AuthService,private storage: Storage) {
    this.initializeApp();

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        // Ajuste a rota conforme necessário. Por exemplo, se a rota de landing page for '', ajustamos para ''
        this.showMenu = event.url !== '/landing';
        this.showMenu = event.url !== '/login';
      }
    });
  }

  async initializeApp() {
    await this.storage.create();
    this.checkLoginStatus();
  }

  async checkLoginStatus() {
    const token = await this.storage.get('userToken');
    if (token) {
      this.router.navigateByUrl('/home');
    } else {
      this.router.navigateByUrl('/login');
    }
  }

  logout() {
    // Limpar o token de autenticação do armazenamento local
    this.storage.remove('userToken');
    this.router.navigateByUrl('/login');
  }

}
