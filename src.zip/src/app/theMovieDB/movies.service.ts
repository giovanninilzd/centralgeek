import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  getDetalhesFilme(id: number) {
    throw new Error('Method not implemented.');
  }

  public favoritos: any[] = [];

  public chave:string = '77c395485220279379909fa9b12604aa';
  public caminhoBase:string = 'https://api.themoviedb.org/3/';
  public servico1:string = 'movie/popular?';
  public servico2:string = 'movie/reviews?';

  constructor(public http:HttpClient) { }

  public getPopularMovies(page=1,language='pt-BR'){
    let endpoint:string =`${this.caminhoBase}${this.servico1}api_key=${this.chave}&page=${page}&language=${language}`;
    return this.http.get(endpoint);
  }

  public getMovieReviews(page=1,language='pt-BR') {
    let endpoint:string =`${this.caminhoBase}${this.servico2}api_key=${this.chave}&page=${page}&language=${language}`;
    return this.http.get(endpoint);
  }
}
