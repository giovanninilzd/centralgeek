
import { Injectable } from "@angular/core";
import { AngularFireAuth } from "@angular/fire/compat/auth";
import { AngularFirestore } from "@angular/fire/compat/firestore";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: "root",
})
export class FireserviceService {
  constructor(
    public firestore: AngularFirestore,
    public auth: AngularFireAuth
  ) {}

  loginWithEmail(data: { email: string, password: string }) {
    return this.auth.signInWithEmailAndPassword(data.email, data.password);
  }

  signup(data: { email: string, password: string }) {
    return this.auth.createUserWithEmailAndPassword(data.email, data.password);
  }

  saveDetails(data: any) {
    return this.firestore.collection("users").doc(data.uid).set({
      // aqui tem que adicionar oque vai para o fire.
      name: data.name,
      email: data.email,
      password: data.password,
      file: data.file
    });
  }

  getDetails(data: { uid: string }) {
    return this.firestore.collection("users").doc(data.uid).valueChanges();
  }

  getSomeData(): Observable<any[]> {
    return this.firestore.collection('suaColecao').valueChanges();
  }

  getCurrentUser() {
    return new Promise<any>((resolve, reject) => {
      this.auth.onAuthStateChanged(user => {
        if (user) {
          // Se o usuário estiver autenticado, buscamos seus detalhes no Firestore
          this.firestore.collection("users").doc(user.uid).valueChanges().subscribe(userData => {
            resolve(userData);
          }, error => {
            reject(error);
          });
        } else {
          resolve(null); // Retorna null se não houver usuário autenticado
        }
      });
    });
  }
}
