import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private afAuth: AngularFireAuth,
    private router: Router
  ) {}

  // Método para fazer logout
  async logout() {
    try {
      await this.afAuth.signOut();
      // Redirecionar para a página de login após o logout
      this.router.navigate(['/login']);
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
    }
  }

  // Método para verificar se o usuário está autenticado
  isAuthenticated(): boolean {
    // Lógica para verificar o estado de autenticação, se necessário
    // Por exemplo, você pode verificar se o usuário está autenticado com o Firebase
    return true; // Substitua isso com a lógica real de verificação de autenticação
  }
}
