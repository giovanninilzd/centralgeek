import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AngularFireModule } from '@angular/fire/compat';
import { environment } from '../environments/environment';

import { AngularFireAuthModule } from '@angular/fire/compat/auth';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { getAuth, provideAuth } from '@angular/fire/auth';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';
import { getStorage, provideStorage } from '@angular/fire/storage';
import { IonicStorageModule } from '@ionic/storage-angular';

@NgModule({
  declarations: [AppComponent],
  imports: [
    AngularFireModule.initializeApp(environment.firebaseConfig),AngularFireAuthModule,
    BrowserModule,IonicStorageModule.forRoot(),
    IonicModule.forRoot(),
    HttpClientModule,
    AppRoutingModule, provideFirebaseApp(() => initializeApp({"projectId":"central-geek","appId":"1:720899530950:web:3f7eea050797d280db37c7","storageBucket":"central-geek.appspot.com","apiKey":"AIzaSyBwcLJ7NH3Xb6GrLPZlTs0OjKpae4OwCMs","authDomain":"central-geek.firebaseapp.com","messagingSenderId":"720899530950","measurementId":"G-0PGNX3EJCJ"})), provideAuth(() => getAuth()), provideFirestore(() => getFirestore()), provideStorage(() => getStorage()),
    
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
})
export class AppModule {}
