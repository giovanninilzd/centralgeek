import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FireserviceService } from '../services/fireservice.service';
import { ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  public email: string = '';
  public password: string = '';

  constructor(
    public router: Router,
    public fireService: FireserviceService,
    private toastController: ToastController,
    private storage: Storage
  ) { }

  async ngOnInit() {
    await this.storage.create();
    this.checkLoginStatus();
  }

  async login() {
    try {
      const res = await this.fireService.loginWithEmail({ email: this.email, password: this.password });
      if (res.user?.uid) {
        // Login bem-sucedido
        await this.storage.set('userToken', res.user?.uid);
        this.presentToast('Login realizado com sucesso.', 'success');
        this.router.navigateByUrl('/home');
      }
    } catch (error: any) {
      if (error.code === 'auth/invalid-email' || error.code === 'auth/user-not-found') {
        this.presentToast('Email inválido ou usuário não encontrado. Por favor, verifique o email fornecido.', 'danger');
      } else if (error.code === 'auth/wrong-password') {
        this.presentToast('Senha incorreta. Por favor, tente novamente.', 'danger');
      } else {
        this.presentToast('Erro ao fazer login. Por favor, tente novamente mais tarde.', 'danger');
      }
    }
  }

  signup() {
    this.router.navigateByUrl('signup');
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: color
    });
    toast.present();
  }

  async checkLoginStatus() {
    const token = await this.storage.get('userToken');
    if (token) {
      this.router.navigateByUrl('/home');
    }
  }
}
