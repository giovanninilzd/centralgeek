import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membros',
  templateUrl: './membros.page.html',
  styleUrls: ['./membros.page.scss'],
})
export class MembrosPage implements OnInit {
  membros = [
    {
      nome: 'Gustavo Pontes',
      role: 'Desenvolvimento Mobile',
      descricao: 'Especialista em Angular e Ionic.',
      foto: 'assets/gustavo.png'
    },
    {
      nome: 'Anderson Goes',
      role: 'Desenvolvimento Mobile',
      descricao: 'Especialista em Angular e Ionic.',
      foto: 'assets/anderson.png'
    },
    {
      nome: 'Bernardo Louzada',
      role: 'Desenvolvimento Mobile',
      descricao: 'Especialista em Angular e Ionic.',
      foto: 'assets/bernardo.png'
    }
  ];

  constructor() { }

  ngOnInit() { }
}
